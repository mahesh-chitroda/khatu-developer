/*
 * Public API Surface of ng-share
 */

export * from './lib/ng-share.module';
