import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NgShareComponent } from './ng-share.component';

describe('NgShareComponent', () => {
  let component: NgShareComponent;
  let fixture: ComponentFixture<NgShareComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NgShareComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NgShareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
