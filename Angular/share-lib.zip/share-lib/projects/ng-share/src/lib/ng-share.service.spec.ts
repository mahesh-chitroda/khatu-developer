import { TestBed, inject } from '@angular/core/testing';

import { NgShareService } from './ng-share.service';

describe('NgShareService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NgShareService]
    });
  });

  it('should be created', inject([NgShareService], (service: NgShareService) => {
    expect(service).toBeTruthy();
  }));
});
