import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
  name: 'highlightPipe'
})
export class HighlightPipe implements PipeTransform {
  transform(text: string, search: string, highlightClass: string): string {
    if (search) {
      let pattern = search.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&');
      pattern = pattern.split(' ').filter((t) => {
        return t.length > 0;
      }).join('|');
      const regex = new RegExp(pattern, 'gi');
      return search ? text.replace(regex, (match) =>  `<span class="highlight">${match}</span>`) : text;
    }
    return text;
  }11
}
