import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-ng-share',
  template: `
    <p>
      ng-share works!
    </p>
  `,
  styles: []
})
export class NgShareComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
