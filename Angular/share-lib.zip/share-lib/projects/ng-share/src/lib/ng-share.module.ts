import { NgModule } from '@angular/core';
import { NgShareComponent } from './ng-share.component';
import { HighlightPipe } from './pipe/highlight.pipe';
import { SearchPipe } from './pipe/search.pipe';

@NgModule({
  imports: [
  ],
  declarations: [NgShareComponent,HighlightPipe,SearchPipe],
  exports: [NgShareComponent,HighlightPipe,SearchPipe]
})
export class NgShareModule { }
