import { Injectable } from '@angular/core';
import { CountryStateList } from '../model/countrystatelist';

@Injectable()

export class DetailService {
    lstCountryState: Array<CountryStateList>;
    constructor() {
        this.lstCountryState = [
            { Country: 'India', State: 'Gujarat', City: 'Ahmedabad', Place: 'Lal Darawaja' },
            { Country: 'India', State: 'Gujarat', City: 'Ahmedabad', Place: 'Kakariya' },
            { Country: 'India', State: 'Gujarat', City: 'Ahmedabad', Place: 'Bapunagar' },
            { Country: 'US', State: 'XX', City: 'YY', Place: 'KJL' }
        ];
    }

    SearchCountryStateList(searchText: string) {

    }
}
