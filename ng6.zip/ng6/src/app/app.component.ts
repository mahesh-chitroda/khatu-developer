import { Component, OnInit } from '@angular/core';
import { CountryStateDetails } from './model/countrystatedetails';
import { DetailService } from './service/app.service';
import { CountryStateList } from './model/countrystatelist';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  pageTitle = 'Welcome to Angular World';
  searchText = '';
  countrystatedetails: CountryStateDetails = new CountryStateDetails();
  lstCountryState: Array<CountryStateList>;

  constructor(private _detailService: DetailService) {
  }

  ngOnInit() {
    this.lstCountryState = this._detailService.lstCountryState;
  }

}
