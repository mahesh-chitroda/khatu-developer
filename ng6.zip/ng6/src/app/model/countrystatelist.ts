export class CountryStateList {
    public Country: string;
    public State: string;
    public City: string;
    public Place: string;
}
