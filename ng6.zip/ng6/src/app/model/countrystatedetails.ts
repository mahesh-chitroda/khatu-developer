export class CountryStateDetails {
   public CountryName: string;
   public CountryDetails: string;
   public PrimeMinister: string;
   public StateName: string;
   public StateDetails: string;
   public ChiefMinister: string;
}

