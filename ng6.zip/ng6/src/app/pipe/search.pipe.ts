import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'searchPipe'
})

export class SearchPipe implements PipeTransform {
    transform(items: any[], searchText: string): any {
        if (searchText) {
            return items.filter(function (item) {
                return item.Country.toLowerCase().includes(searchText.toLowerCase())
                    || item.State.toLowerCase().includes(searchText.toLowerCase())
                    || item.City.toLowerCase().includes(searchText.toLowerCase())
                    || item.Place.toLowerCase().includes(searchText.toLowerCase());
            });
        }
        return items;
    }
}
